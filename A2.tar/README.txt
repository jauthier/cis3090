README
-------

CIS3090 - Assignment 2

Jessica Authier, 0849720

-------------------------

To compile
-----------

type: "make"

To Run
-------

type: "mpiexec -n <numProceses> ./a2"


Timing 
-------

3 Letters 0m0.196s
4 Letters 0m0.242s
5 Letters 0m0.426s
6 Letters 0m1.352s
7 Letters 0m11.775s
8 Letters 2m3.681s

Anything after 8 distinct letters is 
too long.
