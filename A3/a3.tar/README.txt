
CIS3090 - Assignment 3
-----------------------

Jessica Authier
0849720

-----------------------


To compile type "make"

To run type "./a3 <numThread> <matrixSize>" or "./a3 -g"
