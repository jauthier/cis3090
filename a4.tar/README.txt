README
-------

CIS3090 - Assignment 4

Jessica Authier, 0849720

-------------------------

To compile
-----------

type: "make"

To Run
-------

type: "./a4 <numThreads> <matrixSize>" or "./a4 -g"


Limitations
-----------

I could not figure out how to print out the product
vector, when i tried it would only print out pointers


